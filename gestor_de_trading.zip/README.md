
# Gestor de Trading 📊

Aplicação web desenvolvida com Streamlit para análise de operações de trading esportivo.

## Funcionalidades
- Upload de arquivos Excel (.xlsx)
- Exibição de dados e estatísticas básicas

## Como usar
1. Faça o upload do seu arquivo de operações no formato `.xlsx`
2. Veja o resumo estatístico e a tabela com seus dados

Desenvolvido para auxiliar no controle e visualização de performance no trading.
